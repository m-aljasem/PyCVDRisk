#' mesa_coef
#'
#' A data set containing the MESA risk score coefficients (model without CAC)
#'
#'
#' @format A data frame with 1 obs. and 14 variables:
#' \describe{
#'   \item{age}{Coefficient for age}
#'   \item{gender_male}{Coefficient for male gender}
#'   \item{race_chinese}{Coefficient for Chinese race}
#'   \item{race_aa}{Coefficient for African American race}
#'   \item{race_hispanic}{Coefficient for Hispanic race}
#'   \item{diabetes}{Coefficient for diabetes status}
#'   \item{smoker}{Coefficient for current smoker}
#'   \item{totchol}{Coefficient for total cholesterol level}
#'   \item{hdl}{Coefficient for HDL level}
#'   \item{hld_med}{Coefficient for antihyperlipidemic medication}
#'   \item{sbp}{Coefficient for systolic blood pressure}
#'   \item{bp_med}{Coefficient for antihypertensive medication}
#'   \item{fh_heartattack}{Coefficient for family history of heart attacks}
#'   \item{baseline_survival}{Baseline survival}
#' }
#'
#' @references
#' McClelland RL, Jorgensen NW, Budoff M, et al. 10-Year Coronary Heart Disease
#' Risk Prediction Using Coronary Artery Calcium and Traditional Risk Factors:
#' Derivation in the MESA (Multi-Ethnic Study of Atherosclerosis) With
#' Validation in the HNR (Heinz Nixdorf Recall) Study and the DHS
#' (Dallas Heart Study). J Am Coll Cardiol. 2015;66(15):1643-1653.
#' doi:10.1016/j.jacc.2015.08.035
"mesa_coef"
